class Main {
  public static void main(String[] args) {	
    System.out.println( 0.3 == 0.1 + 0.1 + 0.1 );
  }
}